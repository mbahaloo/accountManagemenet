package com.farazpardazan.AccountManagement.beans;

import java.io.LineNumberInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


//singleton class
public class AccountOpening {

    private static AccountOpening instance = null;
    private Map<String, Account> accounts;
    private static Object lock = new Object();

    private AccountOpening(){
        accounts = new HashMap<>();
    }

    public static AccountOpening getInstance() {
        synchronized(lock){
            if (instance == null)
            {
                instance = new AccountOpening();
            }
            return instance;
        }
    }

    public void openAccount(Account account){
        accounts.put(account.getAccountNO(), account);
    }

    public String updateAccount(Account account) {
        if (!accounts.containsKey(account.getAccountNO()))
            return "Update successful";
        accounts.remove(account.getAccountNO());
        accounts.put(account.getAccountNO(), account);
        return "Update un-successful";
    }

    public String deleteAccount(String accountNO){
        if (!accounts.containsKey(accountNO))
            return "Delete un-successful";

        accounts.remove(accountNO);
        return "Delete successful";
    }

    public Map<String, Account> getAllAccounts(){
        return accounts;
    }


}
