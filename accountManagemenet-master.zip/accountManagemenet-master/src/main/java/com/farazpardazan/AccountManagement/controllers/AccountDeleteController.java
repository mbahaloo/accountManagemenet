package com.farazpardazan.AccountManagement.controllers;


import com.farazpardazan.AccountManagement.beans.AccountOpening;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AccountDeleteController {


    @RequestMapping(method = RequestMethod.DELETE, value="/delete/student/{accountNO}")
    public String deleteStudentRecord(@PathVariable("accountNO") String accountNO) {
        return AccountOpening.getInstance().deleteAccount(accountNO);
    }

}
