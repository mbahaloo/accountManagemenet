package com.farazpardazan.AccountManagement.controllers;

import com.farazpardazan.AccountManagement.beans.Account;
import com.farazpardazan.AccountManagement.beans.AccountOpening;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AccountUpdateController {

    @RequestMapping(method = RequestMethod.PUT, value="/update/account")


    @ResponseBody
    public String updateAccountRecord(@RequestBody Account account){
        return AccountOpening.getInstance().updateAccount(account);
    }
}
